
import SearchBar from './components/SearchBar';
function App() {

  return (
     <div className="app">
      
   
    <SearchBar></SearchBar>
      

    </div>
  );
}

export default App;